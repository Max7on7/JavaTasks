package app;

import vehicles.Car;
import vehicles.ElectricCar;

public class TestCar {
    public static void main(String[] args) {
        // Обычная машина
        Car car = new Car("Toyota Camry", "Е123КХ", "Black", 2015, "Ваня", "123", "Бензин");
        System.out.println(car);


        // Электромобиль
        ElectricCar tesla = new ElectricCar("Tesla", "А321ВР", "Red", 2022, "Петя", "321", 100);
        System.out.println(tesla);


        // Проверим сеттеры и геттеры
        tesla.setOwnerName("Маша");
        tesla.setBatteryCapacity(120);

        System.out.println("Новая информация:");
        System.out.println(tesla);
    }
}