package bikeProject;

public interface BikeParts {
    String COMPANY = "BikeCorp";
    String getCompanyName();
    void setCompanyName(String name);
}