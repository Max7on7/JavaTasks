package bikeProject;

public interface RoadParts {
    String terrain = "track racing";
    int getTyreWidth();
    void setTyreWidth(int newValue);
    int getPostHeight();
    void setPostHeight(int newValue);
}
