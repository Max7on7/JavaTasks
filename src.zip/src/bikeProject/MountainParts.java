package bikeProject;

public interface MountainParts {
    String TERRAIN = "off road";

    String getSuspension();
    void setSuspension(String newValue);

    String getType();
    void setType(String newValue);
}
