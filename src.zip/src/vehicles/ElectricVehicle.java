package vehicles;

public interface ElectricVehicle
{
    int getBatteryCapacity();
    void setBatteryCapacity(int batteryCapacity);
}
