import java.util.Date;

public abstract class GeometrciObject implements Comparable<GeometrciObject> {
    String color;
    Boolean filled;

    abstract public double getArea();
    public String getColor() {
        return this.color;
    }
    public void setColor(String color) {
        this.color = color;
    }

    public Boolean getFilled() {
        return this.filled;
    }

    public void setFilled(Boolean filled) {
        this.filled = filled;
    }


    Date dateCreated;
    public Date getDateCreated() {
        return this.dateCreated;
    }
    abstract public String toString();

    @Override
    public int compareTo(GeometrciObject o) {
        return Double.compare(this.getArea(), o.getArea());
    }

    public static GeometrciObject max(GeometrciObject o1, GeometrciObject o2) {
        if (o1 == null) return o2;
        if (o2 == null) return o1;

        return o1.compareTo(o2) > 0 ? o1 : o2;
    }
}
