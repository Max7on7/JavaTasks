package exception_part_of_practice;

import java.util.Scanner;

public class ExceptionMain {
    public static void main(String[] args)  {
        String[] months = {"январь", "февраль", "март", "апрель", "май",
                "июнь", "июль", "август", "сентябрь", "октябрь", "ноябрь", "декабрь"};
        int[] dom = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the num on range (0,12)\n");
        int n = sc.nextInt();

        try {
            if (n != 2 ){
                System.out.println("Month: "+ months[n] + " dom is: " + dom[n]);
            }else {
                System.out.println("Введите год");
                int year = sc.nextInt();
                if ((year%4 ==0 && year%100 !=0) || year%400 ==0)
                {
                    System.out.println("Month: "+ months[n] + " dom is: " + 29);
                }else{
                    System.out.println("Month: "+ months[n] + " dom is: " + 28);
                }

            }
        } catch( ArrayIndexOutOfBoundsException e){
            System.out.println("вели неправильное число");
        }
    }
}
