public class Triangle extends GeometrciObject implements  Colorable {
    double side1, side2, side3;

    public double getSide1(){
        return this.side1;
    }
    public void setSide1(double side){
        this.side1 = side;
    }

    public double getSide2(){
        return this.side2;
    }
    public void setSide2(double side){
        this.side2 = side;
    }

    public double getSide3(){
        return this.side3;
    }
    public void setSide3(double side){
        this.side3 = side;
    }

    Triangle(){
        setSide1(1.0);
        setSide2(1.0);
        setSide3(1.0);
    }

    Triangle(double side1, double side2, double side3)
        throws IllegalTriangleException{

            double maxi = Math.max(Math.max(side1, side2), Math.max(side3, side1));
            double mini = Math.min(Math.min(side1, side2), Math.min(side3, side3));
            double middle = side1 + side2 + side3 - maxi - mini;

            if (maxi >= middle + mini) throw new  IllegalTriangleException("incorrect sides");
            setSide1(side1);
            setSide2(side2);
            setSide3(side3);
        }



    public double getPerimeter(){
        return (this.side1 + this.side2 + this.side3)/2;
    }

    public double getArea(){
        double p = this.getPerimeter();
        return Math.sqrt(p * (p-this.side1) * (p-this.side2) * (p-this.side3));
    }


    public String toString(){
        return "Треугольник: сторона1 = " + this.side1 + " сторона2 = " + this.side2 + " сторона3 = " + this.side3 + "\n";
    }


    @Override
    public void howToColor() {
        System.out.println("Раскрасьте все четыре стороны");
    }
}
