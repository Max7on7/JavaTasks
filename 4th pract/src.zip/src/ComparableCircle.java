public class ComparableCircle  extends Circle implements  Comparable<GeometrciObject>{
    ComparableCircle(){
        super();
    }

    ComparableCircle(double radius){
        super(radius);
    }

}
