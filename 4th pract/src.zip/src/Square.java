public class Square  extends GeometrciObject implements  Colorable{
    private double side;

    public void setSide(double side) {
        this.side = side;
    }
    public double getSide() {
        return this.side;
    }

    public  Square(){
        setSide(0);
    }

    public Square(double side){
        setSide(side);
    }


    @Override
    public double getArea() {
        return this.side*this.side;
    }

    @Override
    public String toString() {
        return "";
    }

    @Override
    public void howToColor() {
        System.out.println("Раскрасьте все четыре стороны");
    }
}
