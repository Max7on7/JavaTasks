public class IllegalTriangleException extends Exception {
    public IllegalTriangleException(String message ) {
        super(message);
    }
}
