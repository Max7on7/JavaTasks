public class Circle  extends GeometrciObject implements  Colorable{
    double radius;
    public void setRadius(double radius) {
        this.radius = radius;
    }
    public double getRadius() {
        return radius;
    }


    @Override
    public double getArea() {
        return radius*radius * Math.PI;
    }

    @Override
    public String toString() {
        return "Circle radius= " + radius + "\n";
    }

    Circle(){
        setRadius(1.0);
        setColor("red");
        setFilled(true);
    }

    Circle(double radius){
        setRadius(radius);
    }

    @Override
    public void howToColor() {
        System.out.println("Раскрасьте все четыре стороны");

    }
}
