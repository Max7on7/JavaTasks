import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.
        double side1, side2, side3;
        String color;
        Boolean isFilled;

        System.out.println("Введите значение трех сторон через пробел");
        Scanner sc = new Scanner(System.in);
        side1 = sc.nextDouble();
        side2 = sc.nextDouble();
        side3 = sc.nextDouble();

        System.out.println("Введите значение цвет");
        color = sc.next();

        System.out.println("Будет ли заливка? true/false");
        isFilled = sc.nextBoolean();

        try {
            Triangle triangle = new Triangle(side1, side2, side3);
            Triangle triangle1 = new Triangle();
            triangle.setColor(color);
            triangle.setFilled(isFilled);

            System.out.println("Площадь: " + triangle.getArea());
            System.out.println("Периметр: " + triangle.getPerimeter());
            System.out.println("Цвет: " + triangle.getColor());
            System.out.println("Закрашен: " + triangle.getFilled());
            GeometrciObject max_triangle = GeometrciObject.max(triangle1, triangle);
            System.out.println("Max Triangle is: " + max_triangle);

            ComparableCircle ccircle1 =new  ComparableCircle();
            ComparableCircle ccircle2 =new  ComparableCircle(4.0);

            if (ccircle1.compareTo(ccircle2) == 0){
                System.out.println("The first Comparable Circle is more than the second");
            }else {
                System.out.println("The second Comparable Circle is more than the first one");
            };

            if (ccircle1.compareTo(triangle) == 0){
                System.out.println("The triangle is more than circle");
            }else {
                System.out.println("The circle is more than triangle");
            };

            GeometrciObject[] massive = new GeometrciObject[5];
            String choice;
            for (int i = 0; i < massive.length; i++) {
                System.out.println("1 - Circle, 2 - Square, 3 - Triangle\n");
                choice = sc.next();
                switch (choice){
                    case "1":
                        massive[i] = new Circle();
                        System.out.println("Is it filled? true/false");
                        isFilled = sc.nextBoolean();
                        massive[i].setFilled(isFilled);
                        break;
                    case "2":
                        massive[i] = new Square();
                        System.out.println("Is it filled? true/false");
                        isFilled = sc.nextBoolean();
                        massive[i].setFilled(isFilled);
                        break;
                    case "3":
                        massive[i] = new Triangle();
                        System.out.println("Is it filled? true/false");
                        isFilled = sc.nextBoolean();
                        massive[i].setFilled(isFilled);
                        break;
                    default:
                        System.out.println("Неправильный ввод. Будет создан треугольник\n");
                        massive[i] = new Triangle();
                        System.out.println("Is it filled? true/false");
                        isFilled = sc.nextBoolean();
                        massive[i].setFilled(isFilled);
                        break;
                }
            }

            for (int i = 0; i < massive.length; i++) {
                System.out.println(massive[i].getArea());
                if (massive[i].getFilled()){
                    ((Colorable) massive[i]).howToColor();
                }
            }





        } catch (IllegalTriangleException  e){
            System.out.println(e.getMessage());
        }





    }
}